<?php

  $variableName = "I am a lady boss";
  $empty_variable = "brown";
  $eyes = "brown";
  $age = 35;

  ?>

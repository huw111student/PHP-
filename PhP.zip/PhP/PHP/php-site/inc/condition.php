<?php

 $tell_joke = "yes";
  if ($tell_joke=="yes")
  {
    echo "How do you spot a modern day spider?<b>";
    echo "She doesn't have a web she has a website!<b>";
  }
  ?>

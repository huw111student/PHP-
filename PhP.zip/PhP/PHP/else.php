<?php
  $question = "What is the biggest ant in the world";
  $answer = "An elephant!";
  if($answer=="A monkey!") {echo "Yep, congrats."; }
  else {echo "Nope, sorry"; }
  ?>

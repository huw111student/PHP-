<?php
 $age = 65;
 $discount_age = 60;
 if ($age>=$discount_age) {
   echo "Congratulations! You qualify for our senior discount.";
 } else {
   echo "Sorry, but you do not qualify for our senior discount.";
 }
 ?>

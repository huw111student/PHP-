</html>

<head>
  <title>Hello Function </title>
</head>

<body>
  <h1> Hello Function</h1>

  <?php

  function hello(){
 echo "Hello world!";


}  

hello();

?>

</body>
</html>

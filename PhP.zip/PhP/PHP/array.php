
<!doctype html>
<head>
  <title>Array</title>
  <head>

    <body>
      <?php

      // Sample of an association Array:
      $customer['first name'] ='John';
      $customer['Last name'] ='Kay';
      $customer ['city'] = 'New York';
      $customer['state'] = 'New York';

  echo "My first name is" .$customer['first name'];
  echo '<br>';

  //Sample of an indexed Array:
  $cars[0] ='Ferrari';
  $cars[1] ='Porsche';
  $cars[2] ='Mustag';
  $cars[3] ='Jaquar';
  $cars[4] ='Audi';

  echo "My other car is a $cars[0]\n";
  echo "My other car is a $cars[3]";
  echo '<br>';

  // Creating associative array using shorthand:
  $restaurant = [
    [
      'name' => 'Nobu',
      'type' => 'sushi',
      'price' => 'Expensive',
    ],

    [
      'name' => 'Burger King',
      'type'     => 'Fast Food',
      'price'      =>'Cheap'
    ]
  ];
  echo $restaurant[0]['name'].'is very'.$restaurant[0]['price'];
  echo '<br>';
  echo $restaurant[1]['name'].'is very'.$restaurant[1]['price'];


 ?>
</body>

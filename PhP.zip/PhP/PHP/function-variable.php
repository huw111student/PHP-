<?php
$question = "What's the unluckiest kind of cat to have?<br>";
if(isset($question)) {
  echo $question;
  echo "A catastrophe!";
} else {
  echo "If you don't have a question you don't get an answer.";
}
?>

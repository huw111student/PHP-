<body>
  <?php

  $msg="Ilike carrots." ;//use the $ in front of var name to declare
  $msg.="and brocoli";//use "." to append to a existing variable (make the variable flexible)

  echo $msg//use echo to print the message.

  ?>
</body>
